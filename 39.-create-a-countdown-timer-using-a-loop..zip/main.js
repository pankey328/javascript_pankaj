// 39. Create a countdown timer using a loop.

// function countDown(seconds) {
    
//     for(let i = seconds; i>=0; i--) {
//         setTimeout(() => {
//             console.log(i);
//             if(i === 0) console.log("Time's up!");
//         }, (seconds - i) * 1000)
//     }
// }

// countDown(10);

let seconds = 10;

for (let i = seconds; i >= 0; i--) {
    setTimeout(() => {
        console.log(i);
        if (i === 0) {
            console.log("Time's up!");
        }
    }, (seconds - i) * 1000);
}

