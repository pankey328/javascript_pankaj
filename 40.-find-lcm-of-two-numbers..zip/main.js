// 40. Find LCM of two numbers.

function findLCM(m,n) {
    
    let lcm = 1;
    
    let i = 2;
    
    while(m>1 || n>1) {
        
        if(m%i==0 || n%i==0){
            lcm = lcm * i;
            
            if(m%i==0) m/=i;
            if(n%i==0) n/=i;
        }
        else {
            i++;
        }
    }
    return lcm;
}

console.log(findLCM(7,5))
console.log(findLCM(12,18))